/*
========================================================
              COOL BHAI — OWNER PROTECTED
========================================================
  Project : COOL MODS OFC 
  Owner   : COOL BHAI
  Contact : +917462010034
  Telegram: @COOLxMODZ

  WARNING:
  This is a DEMO / CREDIT PROTECTION MODULE.
  Unauthorized copying is not permitted.
========================================================
*/

#include <iostream>
#include <string>

namespace COOL_BHAI_OWNER {

    const std::string OWNER_NAME   = "COOL BHAI";
    const std::string OWNER_NUMBER = "+917462010034";
    const std::string OWNER_USER   = "@COOLxMODZ";

    bool OwnerCheck() {
        std::cout << "\n====================================\n";
        std::cout << "       SUNNY BHAI OWNER CHECK\n";
        std::cout << "====================================\n";
        std::cout << "Owner   : " << OWNER_NAME << "\n";
        std::cout << "Number  : " << OWNER_NUMBER << "\n";
        std::cout << "Telegram: " << OWNER_USER << "\n";
        std::cout << "====================================\n";

        return true; // DEMO ONLY
    }

    void Credit() {
        std::cout << "\n[+] CREDIT: COOL BHAI\n";
        std::cout << "[+] Contact: " << OWNER_NUMBER << "\n";
        std::cout << "[+] User: " << OWNER_USER << "\n";
    }
}

int main() {

    if (!ARMAN_BHAI_OWNER::OwnerCheck()) {
        std::cout << "OWNER VERIFICATION FAILED!\n";
        return 1;
    }

    ARMAN_BHAI_OWNER::Credit();

    std::cout << "\n[COOL BHAI] MODULE LOADED SUCCESSFULLY\n";
    std::cout << "[COOL BHAI] DO NOT REMOVE OWNER CREDIT\n";

    return 0;
}